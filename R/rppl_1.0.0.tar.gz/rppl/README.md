The plots used to illustrate the verification of the models, as well as many other plots, have been created with the help of R and the `rppl` package. The central function that the package provides is \verb|rppl::read_model()|. It  parses a `-results.JSON` file as a dataframe.

For additional information, read further
TODO
